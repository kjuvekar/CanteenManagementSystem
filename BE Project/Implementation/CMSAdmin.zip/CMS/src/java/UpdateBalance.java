/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



import CMS.Decrypt;
import CMS.Encrypt;
import CMS.MyDb;
import CMS.sendSMS;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author NITIN ROHIRA
 */
public class UpdateBalance extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
     protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String A = request.getParameter("mn").trim(); 
            String B = request.getParameter("amt").trim(); 
            int D=Integer.parseInt(B);
            //BigInteger a=new BigInteger(A);
            BigInteger b=new BigInteger(B);
            
            int flag=0;
            MyDb db=new MyDb();
            Connection con=db.getCon();
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("Select * from balancerecord");
            while(rs.next())
            {
                String AN1=rs.getString("an1");
                String AN2=rs.getString("an2");
                String BAL1=rs.getString("bal1");
                String BAL2=rs.getString("bal2");

                BigInteger anE=new BigInteger(AN1);
                BigInteger anD=new BigInteger(AN2);
                BigInteger amtE=new BigInteger(BAL1);
                BigInteger amtD=new BigInteger(BAL2);
                Decrypt ob=new Decrypt();
                BigInteger account = ob.decrypt(anD,anE);
                String a=String.valueOf(account);
                BigInteger balance = ob.decrypt(amtD,amtE);
                //out.println(account);
                //out.println(balance);
                if(A.equals(a))
                {
                    BigInteger C = b.add(balance);
                    String bal=String.valueOf(C);
                    Encrypt e=new Encrypt();
                    e.encrypt(bal);
                    BigInteger cE=e.getE();
                    BigInteger cD=e.getD();
                    String Bal1 = String.valueOf(cE);
                    String Bal2 = String.valueOf(cD);
                    
                    String updateQuery = "update balancerecord set bal1='"+Bal1+"',bal2='"+Bal2+"' where an2='" + AN2 + "'";
                    PreparedStatement ps1 = con.prepareStatement(updateQuery);
                    ps1.executeUpdate();
                    flag=1;
                    String updateQuery2 = "insert into transaction(type,amount,mn) values('Recharge','"+D+"','"+A+"')";
                    PreparedStatement ps2 = con.prepareStatement(updateQuery2);
                    ps2.executeUpdate();
                    
                    sendSMS ob2=new sendSMS(A,D);
                    ob2.sendAddConfirmation(bal);
                    
                    
                        out.println("<p>Balance Updated<p>");
                        RequestDispatcher req = request.getRequestDispatcher("Admin.jsp");
			req.include(request, response);
                        con.commit();
                        con.close();
                        break;
                }
                
            }
            if(flag==0)
            {
                                    out.println("<p>Balance Update Failed<p>");
                RequestDispatcher req = request.getRequestDispatcher("Admin.jsp");
                    req.include(request, response);
            }
        } catch (SQLException ex) {
            
        } 
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
