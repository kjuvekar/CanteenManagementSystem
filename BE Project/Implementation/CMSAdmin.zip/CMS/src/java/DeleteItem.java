/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import CMS.MyDb;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author NITIN ROHIRA
 */
public class DeleteItem extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String itemname=request.getParameter("itemname");
            
            MyDb db=new MyDb();
            Connection con=db.getCon();
            Statement st=con.createStatement();
            
            String q="Select itemcode from menu where itemname='"+itemname+"'";
            ResultSet rs=st.executeQuery(q);
            rs.next();
            String itemcode=rs.getString("itemcode");
            
            if(itemcode==null || "".equals(itemcode))
            {     
                out.println("Item Not Found!");
                 RequestDispatcher req = request.getRequestDispatcher("Admin.jsp");
			req.include(request, response);
            }
            else
            {
            String updateQuery = "delete from menu where itemcode='"+itemcode+"'";
                    PreparedStatement ps1 = con.prepareStatement(updateQuery);
                    int i = ps1.executeUpdate();
                    if(i>0){
                    out.println("Item deleted.Menu Updated.");
                    //session.setAttribute("uname","admin");
                    RequestDispatcher req = request.getRequestDispatcher("Admin.jsp");
			req.include(request, response);
                        con.commit();
                        con.close();
                    }    
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(DeleteItem.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
