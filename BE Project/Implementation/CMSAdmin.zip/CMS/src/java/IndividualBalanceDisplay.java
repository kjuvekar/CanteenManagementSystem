/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import CMS.Decrypt;
import CMS.MyDb;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author NITIN ROHIRA
 */
public class IndividualBalanceDisplay extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String A = request.getParameter("mn"); 
            MyDb db=new MyDb();
            Connection con=db.getCon();
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("Select * from balancerecord");
            out.println("<head><meta name='viewport' content='width=device-width, initial-scale=1.0'>");
            out.println("<style>th,td,tr{padding:10px;width:75%;}table,td{border: 1px solid black;}</style>");
            out.println("<link href='https://fonts.googleapis.com/css?family=Raleway' rel='stylesheet'>");
            out.println("<link rel='stylesheet' type='text/css' href='Admin.css'>");
            out.println("<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'></head>");
            out.println("<body style='width: 60%;margin-right: 20%;margin-left: 20%;background-color: #ccc;'>");
            out.println("<table style='margin-left:30%;'>");
            out.println("<th><tr><td>Account No.</td><td>Balance</td></tr></th>");
            while(rs.next())
            {
                String AN1=rs.getString("an1");
                String AN2=rs.getString("an2");
                String BAL1=rs.getString("bal1");
                String BAL2=rs.getString("bal2");

                BigInteger anE=new BigInteger(AN1);
                BigInteger anD=new BigInteger(AN2);
                BigInteger amtE=new BigInteger(BAL1);
                BigInteger amtD=new BigInteger(BAL2);
                Decrypt ob=new Decrypt();
                BigInteger account = ob.decrypt(anD,anE);
                String a=String.valueOf(account);
                BigInteger balance = ob.decrypt(amtD,amtE);
                if(A.equals(a))
                {
                    out.println("<tr><td>"+account+"</td>");
                    out.println("<td>"+balance+"</td></tr>");
                }
            }
            out.println("</table>");
            out.println("<form action='Admin.jsp' method='post'><input type='submit' style=\"margin-left:30%;background-color: black;width:40%;font-family: Raleway;font-size: 17px;color: white;cursor: pointer;\" value='Back'></form>");
            out.println("</body>");    
        } catch (SQLException ex) {
            Logger.getLogger(BalanceDisplay.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
