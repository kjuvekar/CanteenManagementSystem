/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



import CMS.Decrypt;
import CMS.MyDb;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author NITIN ROHIRA
 */
public class BalanceRetrieve {
    public BigInteger getacc (BigInteger a)
    {
        try{
            MyDb db=new MyDb();
            Connection con=db.getCon();
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("Select * from balancerecord");
            while(rs.next())
            {
                String AN1=rs.getString("an1");
                BigInteger an1=new BigInteger(AN1);
                String AN2=rs.getString("an2");
                String BAL1=rs.getString("bal1");
                String BAL2=rs.getString("bal2");

                BigInteger anE=new BigInteger(AN1);
                BigInteger anD=new BigInteger(AN2);
                /*BigInteger amtE=new BigInteger(BAL1);
                BigInteger amtD=new BigInteger(BAL2);*/
                Decrypt ob=new Decrypt();
                BigInteger account = ob.decrypt(anD,anE);
                /*BigInteger balance = ob.decrypt(amtD,amtE)*/
                
                if(account==a)
                return an1;
            }
        } catch(SQLException E){}
    return null;
    }

    /**
     *
     * @param a
     * @return
     */
    public BigInteger getbal (BigInteger a)
    {
        try{
            MyDb db=new MyDb();
            Connection con=db.getCon();
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("Select * from balancerecord");
            while(rs.next())
            {
                String AN1=rs.getString("an1");
                BigInteger an1=new BigInteger(AN1);
                String AN2=rs.getString("an2");
                String BAL1=rs.getString("bal1");
                String BAL2=rs.getString("bal2");

                BigInteger anE=new BigInteger(AN1);
                BigInteger anD=new BigInteger(AN2);
                BigInteger amtE=new BigInteger(BAL1);
                BigInteger amtD=new BigInteger(BAL2);
                Decrypt ob=new Decrypt();
                BigInteger account = ob.decrypt(anD,anE);
                BigInteger balance = ob.decrypt(amtD,amtE);
                
                if(account==a)
                return balance;
            }
        } catch(SQLException E){}
    return null;
    }
}
