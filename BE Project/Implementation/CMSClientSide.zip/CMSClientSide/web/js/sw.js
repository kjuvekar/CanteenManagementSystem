(function() {
  'use strict';

  // TODO - 3.1: Add install and activate event listeners

  // TODO - 3.3: Add a comment to change the service worker

  // TODO - 4: Add fetch listener

})();