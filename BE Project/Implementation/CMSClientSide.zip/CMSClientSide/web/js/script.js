/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
   
$(document).ready(   function () {
               $("#menuorder").jqxComboBox({ selectedIndex: null ,template: "warning", width: 290, height: 40 });
       $('#menuorder').on('select', function (event) {
       var args = event.args;
       if (args) {
           // index represents the item's index.                          
           var index = args.index;
           var item = args.item;
           // get item's label and value.
           var value = item.value;
          document.getElementById("menuorder").value=value;
       }    
    });});  
                                                                                    var active1=document.getElementById("home");
                                                                                    active1.classList.add("active");
                                                                                    var active=document.getElementById("homea");
                                                                                    active.classList.add("active");
                                                                                   active.href="#menutaker";
                                                                                    if(sessionStorage.length !==0){
                                                                                     var retrieveditems = sessionStorage.getItem("items");
                                                                                     var item = JSON.parse(retrieveditems);
                                                                                     var retrievedno = sessionStorage.getItem("quants");
                                                                                     var no = JSON.parse(retrievedno);
                                                                                   document.getElementById("shoppingcarticon").innerHTML=item.length;   
                                                                                     }
                                                                                       else{
                                                                                 var item=[];
                                                                                 var no=[];}
//                var item=[];
//                var no=[];
                function addcart(){
                    var h=document.getElementById("menuorder").value;
                    var j=item.indexOf(h);
                    if(h== null){
                        document.getElementById("cartitem").innerHTML= "Sorry! Please Select an Item";
                    }
                    else if(j != -1 && item.length != 0){
                    document.getElementById("cartitem").innerHTML = "Item already exists!</br><button type='button' class='btn btn-info pull-right' data-dismiss='modal'>Continue Adding</button>";
                    }else{              
                    item.push(h);
                    var text="<ul class='list-group'><form action='order.jsp' method='post'>";
                    for (i = 0; i < item.length; i++) {
                    text += "<div class='row' id='"+i+"'><li style='background-color:#012521 !important;color:white !important;text-align: center;font-size: 1.3rem;' class='list-group-item col'>" + item[i] + "</li><input type='button' class='btn btn-outline-success col' style='font-size: xx-large;' onclick='add(this)' value='&#8593;' id='"+i+"'><input class='col text-center' id='qt"+i+"' type='number' value='1' onchange='quantitychange(this)'><input id='"+i+"' type='button' class='btn btn-outline-success col' style='font-size: xx-large;' onclick='sub(this)' value='&#8595;'><input type='button' class='btn btn-danger col' onclick='remove(this)' style='font-size: large;' value='&#10006;' id='"+i+"'></div>";
                    }
                    text +=" <input type='submit' class='btn btn-outline-success pull-right' value='Checkout' onclick='checkout()'> <button type='button' class='btn btn-info pull-right' data-dismiss='modal'>Continue Adding</button></form></ul>";
                    document.getElementById("cartitem").innerHTML = text;}
                        var p;
                        for(p=0;p<i;p++){
                        var q="qt".concat(p);
                        if(no.length == 0 || no.length == p ){
                        var input2 = document.getElementById(q).value;
                        no[p]=input2;
                        }
                        else{
                        var cnt=document.getElementById(q);
                        cnt.value=no[p];
                       var input = document.getElementById(q).value;
                       no[p]=input;
                        }
                        }document.getElementById("shoppingcarticon").innerHTML=item.length;
                        checkout();
                        }
                function add(v){
                        var x=v.id;
                                                x="qt".concat(x);
                                                var z=document.getElementById(x).value;
                                                var y=parseInt(z);
                        y= y + 1;
                                                document.getElementById(x).value= y ;
                                                quantitychange1(y,v.id);
                                                checkout();
                                                }
                function sub(v){
                        var x=v.id;
                                                x="qt".concat(x);
                                                var z=document.getElementById(x).value;
                                                var y=parseInt(z);
                                                if(y!=1){
                        y= y - 1;}
                                                document.getElementById(x).value= y ;
                                            quantitychange1(y,v.id);checkout();}
                                 function remove(k){
                                     var j=k.id;
                                     item.splice(j,1);
                                     no.splice(j,1);
                                     if(item.length==0){
                                      document.getElementById("cartitem").innerHTML = "Sorry No Items in Cart!";                                         
                                     }
                                     else
                                     {
                                        var text="<ul class='list-group'><form action='order.jsp' method='post'>";
                    for (i = 0; i < item.length; i++) {
                    text += "<div class='row' id='"+i+"'><li style='background-color:#012521 !important;color:white !important;text-align: center;font-size: 1.3rem;' class='list-group-item col'>" + item[i] + "</li><input type='button' class='btn btn-outline-success col' style='font-size: xx-large;' onclick='add(this)' value='&#8593;' id='"+(i)+"'><input class='col text-center' id='qt"+i+"' type='number' value='1' onchange='quantitychange(this)'><input id='"+(i)+"' type='button' class='btn btn-outline-success col' style='font-size: xx-large;' onclick='sub(this)' value='&#8595;'><input type='button' class='btn btn-danger col' onclick='remove(this)' style='font-size: large;' value='&#10006;' id='"+i+"'></div>";}
                    text +=" <center><button type='button' class='bubbly-button ' data-dismiss='modal'>Continue Adding</button>   <button type='submit' class='bubbly-button' style='--bgcl1:#05c5de;' 'onclick='checkout()'>Checkout</button></center></form></ul>";
                    document.getElementById("cartitem").innerHTML = text;}
                                        var p;
                                       // console.log(i);
                                        for(p=0;p<i;p++){
                                        var q="qt".concat(p);
                                        //console.log(q);
                                        if(no.length == 0 || no.length == p ){
                                       // console.log(p);//var input2 = document.getElementById(q).value;
                                        //no[p]=input2;
                                       }
                                        else{
                                        var cnt=document.getElementById(q);
                                        cnt.value=no[p];
                                        var input = document.getElementById(q).value;
                                        no[p]=input;
                                        }
                                        }
                                        document.getElementById("shoppingcarticon").innerHTML=item.length;
                                        checkout();} 
                                function showcart(){
                                    if(item.length==0){
                                      document.getElementById("cartitem").innerHTML = "Sorry No Items in Cart!";                                         
                                     }
                                     else
                                     {
                                        var text="<ul class='list-group'><form action='order.jsp' method='post'>";
                    for (var i = 0; i < item.length; i++) {
                    text += "<div class='row' id='"+i+"'><li style='background-color:#012521 !important;color:white !important;text-align: center;font-size: 1.3rem;' class='list-group-item col'>" + item[i] + "</li><input type='button' class='btn btn-outline-success col' style='font-size: xx-large;' onclick='add(this)' value='&#8593;' id='"+(i)+"'><input class='col text-center' id='qt"+i+"' type='number' value='1' onchange='quantitychange(this)'><input id='"+(i)+"' type='button' class='btn btn-outline-success col' style='font-size: xx-large;' onclick='sub(this)' value='&#8595;'><input type='button' class='btn btn-danger col' onclick='remove(this)' style='font-size: large;' value='&#10006;' id='"+i+"'></div>";}
                    text +=" <center><button type='button' class='bubbly-button' data-dismiss='modal'>Continue Adding</button>   <button type='submit' class='bubbly-button' style='--bgcl1:#05c5de;' 'onclick='checkout()'>Checkout</button></center></form></ul>";
                    document.getElementById("cartitem").innerHTML = text;}
                                var p;
                                        for(p=0;p<i;p++){
                                        var q="qt".concat(p);
                                        if(no.length == 0 || no.length == p ){
                                        var input2 = document.getElementById(q).value;
                                        no[p]=input2;
                                       }
                                        else{
                                        var cnt=document.getElementById(q);
                                        cnt.value=no[p];
                                        var input = document.getElementById(q).value;
                                        no[p]=input;
                                        }
                                        }
                                        checkout();
                                        }
                                        function quantitychange(q){
                                        var input=q.value; 
                                        var id=q.id;
                                        var position=id.substring(2);
                                        quantitychange1(input,position);
                                        checkout();
                                        }
                                        function quantitychange1(q,p){
                                        no[p]=q;
                                       }
                                       function checkout(){
                                        sessionStorage.setItem("items", JSON.stringify(item));
                                        sessionStorage.setItem("quants", JSON.stringify(no));
                                        }   
                               
   

