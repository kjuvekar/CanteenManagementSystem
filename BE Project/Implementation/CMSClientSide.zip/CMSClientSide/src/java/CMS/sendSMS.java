//package CMS;
//
//import java.net.*; 
// 
//public class sendSMS {
// static String mn;
// static int otp;   
// static String requestUrl;
// public sendSMS(String a,int b){
//     mn=a.trim();
//     otp=b;
// }
//public static void sendOTP() {
//try {
//String apikey = "sUpr4MdfDUedA9LW7GIcJA";
//String senderid = "TESTIN";
//String channel = "2";
//String DCS = "0";
//String flashsms = "0";
//String mobile = "91"+mn;
//String message = "Thank you for using V.E.S. Canteen App. Your OTP is "+otp+".";
//String route = "13";
// 
//https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
// 
// 
//requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
//"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
//"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
//"&channel=" + URLEncoder.encode(channel, "UTF-8") +
//"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
//"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
//"&number=" + URLEncoder.encode(mobile, "UTF-8") +
//"&text=" + URLEncoder.encode(message, "UTF-8") +
//"&route=" + URLEncoder.encode(route, "UTF-8");
// 
// 
// 
//URL url = new URL(requestUrl);
//HttpURLConnection uc = (HttpURLConnection)url.openConnection();
// 
//System.out.println(uc.getResponseMessage());
// 
//uc.disconnect();
// 
//} catch(Exception ex) {
//System.out.println(ex.getMessage());
// 
//}
//}
//
//public static void sendBalUpdate() {
//try {
//String apikey = "sUpr4MdfDUedA9LW7GIcJA";
//String senderid = "TESTIN";
//String channel = "2";
//String DCS = "0";
//String flashsms = "0";
//String mobile = "91"+mn;
//String message = "Thank you for using V.E.S. Canteen App. Amount of Rs."+otp+" deducted from your E-wallet.";
//String route = "13";
// 
//https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
// 
// 
//requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
//"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
//"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
//"&channel=" + URLEncoder.encode(channel, "UTF-8") +
//"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
//"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
//"&number=" + URLEncoder.encode(mobile, "UTF-8") +
//"&text=" + URLEncoder.encode(message, "UTF-8") +
//"&route=" + URLEncoder.encode(route, "UTF-8");
// 
// 
// 
//URL url = new URL(requestUrl);
//HttpURLConnection uc = (HttpURLConnection)url.openConnection();
// 
//System.out.println(uc.getResponseMessage());
// 
//uc.disconnect();
// 
//} catch(Exception ex) {
//System.out.println(ex.getMessage());
// 
//}
//}
//public static void sendOrder() {
//try {
//String apikey = "sUpr4MdfDUedA9LW7GIcJA";
//String senderid = "TESTIN";
//String channel = "2";
//String DCS = "0";
//String flashsms = "0";
//String mobile = "91"+mn;
//String message = "Thank you for using V.E.S. Canteen. Your ORDERID "+otp+" is successfully placed.";
//String route = "13";
// 
//https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
// 
// 
//requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
//"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
//"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
//"&channel=" + URLEncoder.encode(channel, "UTF-8") +
//"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
//"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
//"&number=" + URLEncoder.encode(mobile, "UTF-8") +
//"&text=" + URLEncoder.encode(message, "UTF-8") +
//"&route=" + URLEncoder.encode(route, "UTF-8");
// 
// 
// 
//URL url = new URL(requestUrl);
//HttpURLConnection uc = (HttpURLConnection)url.openConnection();
// 
//System.out.println(uc.getResponseMessage());
// 
//uc.disconnect();
// 
//} catch(Exception ex) {
//System.out.println(ex.getMessage());
// 
//}
//}
// public static void sendConfirmation() {
//try {
//String apikey = "sUpr4MdfDUedA9LW7GIcJA";
//String senderid = "TESTIN";
//String channel = "2";
//String DCS = "0";
//String flashsms = "0";
//String mobile = "91"+mn;
//String message = "Welcome to V.E.S. Canteen App "+mn+". You have been succesfully registered.";
//String route = "13";
// 
//https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
// 
// 
//requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
//"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
//"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
//"&channel=" + URLEncoder.encode(channel, "UTF-8") +
//"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
//"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
//"&number=" + URLEncoder.encode(mobile, "UTF-8") +
//"&text=" + URLEncoder.encode(message, "UTF-8") +
//"&route=" + URLEncoder.encode(route, "UTF-8");
// 
// 
// 
//URL url = new URL(requestUrl);
//HttpURLConnection uc = (HttpURLConnection)url.openConnection();
// 
//System.out.println(uc.getResponseMessage());
// 
//uc.disconnect();
// 
//} catch(Exception ex) {
//System.out.println(ex.getMessage());
// 
//}
// }
// public static void sendAddConfirmation(String b) {
//try {
//String apikey = "sUpr4MdfDUedA9LW7GIcJA";
//String senderid = "TESTIN";
//String channel = "2";
//String DCS = "0";
//String flashsms = "0";
//String mobile = "91"+mn;
//String message = "Amount of Rs. "+otp+" added to your account.Updated Balance is Rs."+b+" .";
//String route = "13";
// 
//https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
// 
// 
//requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
//"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
//"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
//"&channel=" + URLEncoder.encode(channel, "UTF-8") +
//"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
//"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
//"&number=" + URLEncoder.encode(mobile, "UTF-8") +
//"&text=" + URLEncoder.encode(message, "UTF-8") +
//"&route=" + URLEncoder.encode(route, "UTF-8");
// 
// 
// 
//URL url = new URL(requestUrl);
//HttpURLConnection uc = (HttpURLConnection)url.openConnection();
// 
//System.out.println(uc.getResponseMessage());
// 
//uc.disconnect();
// 
//} catch(Exception ex) {
//System.out.println(ex.getMessage());
// 
//}
//}
// public static void sendRefund(String b) {
//try {
//String apikey = "sUpr4MdfDUedA9LW7GIcJA";
//String senderid = "TESTIN";
//String channel = "2";
//String DCS = "0";
//String flashsms = "0";
//String mobile = "91"+mn;
//String message = "Amount of Rs. "+otp+" refunded to your account.Updated Balance is Rs."+b+" .";
//String route = "13";
// 
//https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
// 
// 
//requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
//"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
//"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
//"&channel=" + URLEncoder.encode(channel, "UTF-8") +
//"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
//"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
//"&number=" + URLEncoder.encode(mobile, "UTF-8") +
//"&text=" + URLEncoder.encode(message, "UTF-8") +
//"&route=" + URLEncoder.encode(route, "UTF-8");
// 
// 
// 
//URL url = new URL(requestUrl);
//HttpURLConnection uc = (HttpURLConnection)url.openConnection();
// 
//System.out.println(uc.getResponseMessage());
// 
//uc.disconnect();
// 
//} catch(Exception ex) {
//System.out.println(ex.getMessage());
// 
//}
//}
// public static void AcceptOrder() {
//try {
//String apikey = "sUpr4MdfDUedA9LW7GIcJA";
//String senderid = "TESTIN";
//String channel = "2";
//String DCS = "0";
//String flashsms = "0";
//String mobile = "91"+mn;
//String message = "Thank you for using V.E.S. Canteen. Your ORDERID "+otp+" is accepted.";
//String route = "13";
// 
//https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
// 
// 
//requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
//"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
//"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
//"&channel=" + URLEncoder.encode(channel, "UTF-8") +
//"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
//"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
//"&number=" + URLEncoder.encode(mobile, "UTF-8") +
//"&text=" + URLEncoder.encode(message, "UTF-8") +
//"&route=" + URLEncoder.encode(route, "UTF-8");
// 
// 
// 
//URL url = new URL(requestUrl);
//HttpURLConnection uc = (HttpURLConnection)url.openConnection();
// 
//System.out.println(uc.getResponseMessage());
// 
//uc.disconnect();
// 
//} catch(Exception ex) {
//System.out.println(ex.getMessage());
// 
//}
//}
// public static void DeclineOrder() {
//try {
//String apikey = "sUpr4MdfDUedA9LW7GIcJA";
//String senderid = "TESTIN";
//String channel = "2";
//String DCS = "0";
//String flashsms = "0";
//String mobile = "91"+mn;
//String message = "Thank you for using V.E.S. Canteen. Sorry!Your ORDERID "+otp+" is declined due to some issues.Refund will be processed soon.";
//String route = "13";
// 
//https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
// 
// 
//requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
//"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
//"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
//"&channel=" + URLEncoder.encode(channel, "UTF-8") +
//"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
//"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
//"&number=" + URLEncoder.encode(mobile, "UTF-8") +
//"&text=" + URLEncoder.encode(message, "UTF-8") +
//"&route=" + URLEncoder.encode(route, "UTF-8");
// 
// 
// 
//URL url = new URL(requestUrl);
//HttpURLConnection uc = (HttpURLConnection)url.openConnection();
// 
//System.out.println(uc.getResponseMessage());
// 
//uc.disconnect();
// 
//} catch(Exception ex) {
//System.out.println(ex.getMessage());
// 
//}
//}
//  public static void CompleteOrder() {
//try {
//String apikey = "sUpr4MdfDUedA9LW7GIcJA";
//String senderid = "TESTIN";
//String channel = "2";
//String DCS = "0";
//String flashsms = "0";
//String mobile = "91"+mn;
//String message = "Thank you for using V.E.S. Canteen.Your order with ORDERID "+otp+" is deivered.";
//String route = "13";
// 
//https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
// 
// 
//requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
//"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
//"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
//"&channel=" + URLEncoder.encode(channel, "UTF-8") +
//"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
//"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
//"&number=" + URLEncoder.encode(mobile, "UTF-8") +
//"&text=" + URLEncoder.encode(message, "UTF-8") +
//"&route=" + URLEncoder.encode(route, "UTF-8");
// 
// 
// 
//URL url = new URL(requestUrl);
//HttpURLConnection uc = (HttpURLConnection)url.openConnection();
// 
//System.out.println(uc.getResponseMessage());
// 
//uc.disconnect();
// 
//} catch(Exception ex) {
//System.out.println(ex.getMessage());
// 
//}
//}
//}

package CMS;

import java.net.*; 
 
public class sendSMS {
 static String mn;
 static int otp;   
 static String requestUrl;
 public sendSMS(String a,int b){
     mn=a.trim();
     otp=b;
 }
public static void sendOTP() {
try {
String apikey = "xg8jRGjl7EKJjEEa6inBXg";
String senderid = "TESTIN";
String channel = "2";
String DCS = "0";
String flashsms = "0";
String mobile = "91"+mn;
String message = "Thank you for using V.E.S. Canteen App. Your OTP is "+otp+".";
String route = "13";
 
https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
 
 
requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
"&channel=" + URLEncoder.encode(channel, "UTF-8") +
"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
"&number=" + URLEncoder.encode(mobile, "UTF-8") +
"&text=" + URLEncoder.encode(message, "UTF-8") +
"&route=" + URLEncoder.encode(route, "UTF-8");
 
 
 
URL url = new URL(requestUrl);
HttpURLConnection uc = (HttpURLConnection)url.openConnection();
 
System.out.println(uc.getResponseMessage());
 
uc.disconnect();
 
} catch(Exception ex) {
System.out.println(ex.getMessage());
 
}
}

public static void sendBalUpdate() {
try {
String apikey = "xg8jRGjl7EKJjEEa6inBXg";
String senderid = "TESTIN";
String channel = "2";
String DCS = "0";
String flashsms = "0";
String mobile = "91"+mn;
String message = "Thank you for using V.E.S. Canteen App. Amount of Rs."+otp+" deducted from your E-wallet.";
String route = "13";
 
https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
 
 
requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
"&channel=" + URLEncoder.encode(channel, "UTF-8") +
"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
"&number=" + URLEncoder.encode(mobile, "UTF-8") +
"&text=" + URLEncoder.encode(message, "UTF-8") +
"&route=" + URLEncoder.encode(route, "UTF-8");
 
 
 
URL url = new URL(requestUrl);
HttpURLConnection uc = (HttpURLConnection)url.openConnection();
 
System.out.println(uc.getResponseMessage());
 
uc.disconnect();
 
} catch(Exception ex) {
System.out.println(ex.getMessage());
 
}
}
public static void sendOrder() {
try {
String apikey = "xg8jRGjl7EKJjEEa6inBXg";
String senderid = "TESTIN";
String channel = "2";
String DCS = "0";
String flashsms = "0";
String mobile = "91"+mn;
String message = "Thank you for using V.E.S. Canteen. Your ORDERID "+otp+" is successfully placed.";
String route = "13";
 
https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
 
 
requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
"&channel=" + URLEncoder.encode(channel, "UTF-8") +
"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
"&number=" + URLEncoder.encode(mobile, "UTF-8") +
"&text=" + URLEncoder.encode(message, "UTF-8") +
"&route=" + URLEncoder.encode(route, "UTF-8");
 
 
 
URL url = new URL(requestUrl);
HttpURLConnection uc = (HttpURLConnection)url.openConnection();
 
System.out.println(uc.getResponseMessage());
 
uc.disconnect();
 
} catch(Exception ex) {
System.out.println(ex.getMessage());
 
}
}
 public static void sendConfirmation() {
try {
String apikey = "xg8jRGjl7EKJjEEa6inBXg";
String senderid = "TESTIN";
String channel = "2";
String DCS = "0";
String flashsms = "0";
String mobile = "91"+mn;
String message = "Welcome to V.E.S. Canteen App "+mn+". You have been succesfully registered.";
String route = "13";
 
https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
 
 
requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
"&channel=" + URLEncoder.encode(channel, "UTF-8") +
"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
"&number=" + URLEncoder.encode(mobile, "UTF-8") +
"&text=" + URLEncoder.encode(message, "UTF-8") +
"&route=" + URLEncoder.encode(route, "UTF-8");
 
 
 
URL url = new URL(requestUrl);
HttpURLConnection uc = (HttpURLConnection)url.openConnection();
 
System.out.println(uc.getResponseMessage());
 
uc.disconnect();
 
} catch(Exception ex) {
System.out.println(ex.getMessage());
 
}
 }
 public static void sendAddConfirmation(String b) {
try {
String apikey = "xg8jRGjl7EKJjEEa6inBXg";
String senderid = "TESTIN";
String channel = "2";
String DCS = "0";
String flashsms = "0";
String mobile = "91"+mn;
String message = "Amount of Rs. "+otp+" added to your account.Updated Balance is Rs."+b+" .";
String route = "13";
 
https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
 
 
requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
"&channel=" + URLEncoder.encode(channel, "UTF-8") +
"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
"&number=" + URLEncoder.encode(mobile, "UTF-8") +
"&text=" + URLEncoder.encode(message, "UTF-8") +
"&route=" + URLEncoder.encode(route, "UTF-8");
 
 
 
URL url = new URL(requestUrl);
HttpURLConnection uc = (HttpURLConnection)url.openConnection();
 
System.out.println(uc.getResponseMessage());
 
uc.disconnect();
 
} catch(Exception ex) {
System.out.println(ex.getMessage());
 
}
}
 public static void sendRefund(String b) {
try {
String apikey = "xg8jRGjl7EKJjEEa6inBXg";
String senderid = "TESTIN";
String channel = "2";
String DCS = "0";
String flashsms = "0";
String mobile = "91"+mn;
String message = "Amount of Rs. "+otp+" refunded to your account.Updated Balance is Rs."+b+" .";
String route = "13";
 
https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
 
 
requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
"&channel=" + URLEncoder.encode(channel, "UTF-8") +
"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
"&number=" + URLEncoder.encode(mobile, "UTF-8") +
"&text=" + URLEncoder.encode(message, "UTF-8") +
"&route=" + URLEncoder.encode(route, "UTF-8");
 
 
 
URL url = new URL(requestUrl);
HttpURLConnection uc = (HttpURLConnection)url.openConnection();
 
System.out.println(uc.getResponseMessage());
 
uc.disconnect();
 
} catch(Exception ex) {
System.out.println(ex.getMessage());
 
}
}
 public static void AcceptOrder() {
try {
String apikey = "xg8jRGjl7EKJjEEa6inBXg";
String senderid = "TESTIN";
String channel = "2";
String DCS = "0";
String flashsms = "0";
String mobile = "91"+mn;
String message = "Thank you for using V.E.S. Canteen. Your ORDERID "+otp+" is accepted.";
String route = "13";
 
https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
 
 
requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
"&channel=" + URLEncoder.encode(channel, "UTF-8") +
"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
"&number=" + URLEncoder.encode(mobile, "UTF-8") +
"&text=" + URLEncoder.encode(message, "UTF-8") +
"&route=" + URLEncoder.encode(route, "UTF-8");
 
 
 
URL url = new URL(requestUrl);
HttpURLConnection uc = (HttpURLConnection)url.openConnection();
 
System.out.println(uc.getResponseMessage());
 
uc.disconnect();
 
} catch(Exception ex) {
System.out.println(ex.getMessage());
 
}
}
 public static void DeclineOrder() {
try {
String apikey = "xg8jRGjl7EKJjEEa6inBXg";
String senderid = "TESTIN";
String channel = "2";
String DCS = "0";
String flashsms = "0";
String mobile = "91"+mn;
String message = "Thank you for using V.E.S. Canteen. Sorry!Your ORDERID "+otp+" is declined due to some issues.Refund will be processed soon.";
String route = "13";
 
https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
 
 
requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
"&channel=" + URLEncoder.encode(channel, "UTF-8") +
"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
"&number=" + URLEncoder.encode(mobile, "UTF-8") +
"&text=" + URLEncoder.encode(message, "UTF-8") +
"&route=" + URLEncoder.encode(route, "UTF-8");
 
 
 
URL url = new URL(requestUrl);
HttpURLConnection uc = (HttpURLConnection)url.openConnection();
 
System.out.println(uc.getResponseMessage());
 
uc.disconnect();
 
} catch(Exception ex) {
System.out.println(ex.getMessage());
 
}
}
  public static void CompleteOrder() {
try {
String apikey = "xg8jRGjl7EKJjEEa6inBXg";
String senderid = "TESTIN";
String channel = "2";
String DCS = "0";
String flashsms = "0";
String mobile = "91"+mn;
String message = "Thank you for using V.E.S. Canteen.Your order with ORDERID "+otp+" is deivered.";
String route = "13";
 
https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
 
 
requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
"&channel=" + URLEncoder.encode(channel, "UTF-8") +
"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
"&number=" + URLEncoder.encode(mobile, "UTF-8") +
"&text=" + URLEncoder.encode(message, "UTF-8") +
"&route=" + URLEncoder.encode(route, "UTF-8");
 
 
 
URL url = new URL(requestUrl);
HttpURLConnection uc = (HttpURLConnection)url.openConnection();
 
System.out.println(uc.getResponseMessage());
 
uc.disconnect();
 
} catch(Exception ex) {
System.out.println(ex.getMessage());
 
}
}
}

//package CMS;
//import java.net.*; 
// 
//public class sendSMS {
//static String mn;
//static int otp;   
//static String requestUrl;
//public sendSMS(String a,int b){
//mn=a.trim();
//otp=b;
// }
//public static void sendOTP() {
//try {
//String apikey = "pI2m1rcKm06OUfu9Ox0L0g";
//String senderid = "TESTIN";
//String channel = "2";
//String DCS = "0";
//String flashsms = "0";
//String mobile = "91"+mn;
//String message = "Thank you for using V.E.S. Canteen App. Your OTP is "+otp+".";
//String route = "13";
//https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
//requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
//"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
//"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
//"&channel=" + URLEncoder.encode(channel, "UTF-8") +
//"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
//"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
//"&number=" + URLEncoder.encode(mobile, "UTF-8") +
//"&text=" + URLEncoder.encode(message, "UTF-8") +
//"&route=" + URLEncoder.encode(route, "UTF-8");
//URL url = new URL(requestUrl);
//HttpURLConnection uc = (HttpURLConnection)url.openConnection();
//System.out.println(uc.getResponseMessage());
//uc.disconnect();
//} catch(Exception ex) {
//System.out.println(ex.getMessage());
//}
//}
//public static void sendBalUpdate() {
//try {
//String apikey = "pI2m1rcKm06OUfu9Ox0L0g";
//String senderid = "TESTIN";
//String channel = "2";
//String DCS = "0";
//String flashsms = "0";
//String mobile = "91"+mn;
//String message = "Thank you for using V.E.S. Canteen App. Amount of Rs."+otp+" deducted from your E-wallet.";
//String route = "13";
//https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
//requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
//"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
//"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
//"&channel=" + URLEncoder.encode(channel, "UTF-8") +
//"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
//"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
//"&number=" + URLEncoder.encode(mobile, "UTF-8") +
//"&text=" + URLEncoder.encode(message, "UTF-8") +
//"&route=" + URLEncoder.encode(route, "UTF-8");
//URL url = new URL(requestUrl);
//HttpURLConnection uc = (HttpURLConnection)url.openConnection();
//System.out.println(uc.getResponseMessage());
//uc.disconnect();
//} catch(Exception ex) {
//System.out.println(ex.getMessage());
//}
//}
//public static void sendOrder() {
//try {
//String apikey = "pI2m1rcKm06OUfu9Ox0L0g";
//String senderid = "TESTIN";
//String channel = "2";
//String DCS = "0";
//String flashsms = "0";
//String mobile = "91"+mn;
//String message = "Thank you for using V.E.S. Canteen. Your ORDERID "+otp+" is successfully placed.";
//String route = "13";
//https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
//requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
//"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
//"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
//"&channel=" + URLEncoder.encode(channel, "UTF-8") +
//"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
//"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
//"&number=" + URLEncoder.encode(mobile, "UTF-8") +
//"&text=" + URLEncoder.encode(message, "UTF-8") +
//"&route=" + URLEncoder.encode(route, "UTF-8");
//URL url = new URL(requestUrl);
//HttpURLConnection uc = (HttpURLConnection)url.openConnection();
//System.out.println(uc.getResponseMessage());
//uc.disconnect();
//} catch(Exception ex) {
//System.out.println(ex.getMessage());
// 
//}
//}
// public static void sendConfirmation() {
//try {
//String apikey = "pI2m1rcKm06OUfu9Ox0L0g";
//String senderid = "TESTIN";
//String channel = "2";
//String DCS = "0";
//String flashsms = "0";
//String mobile = "91"+mn;
//String message = "Welcome to V.E.S. Canteen App "+mn+". You have been succesfully registered.";
//String route = "13";
//https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
//requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
//"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
//"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
//"&channel=" + URLEncoder.encode(channel, "UTF-8") +
//"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
//"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
//"&number=" + URLEncoder.encode(mobile, "UTF-8") +
//"&text=" + URLEncoder.encode(message, "UTF-8") +
//"&route=" + URLEncoder.encode(route, "UTF-8");
//URL url = new URL(requestUrl);
//HttpURLConnection uc = (HttpURLConnection)url.openConnection();
//System.out.println(uc.getResponseMessage());
//uc.disconnect();
//} catch(Exception ex) {
//System.out.println(ex.getMessage());
//}
// }
// public static void sendAddConfirmation(String b) {
//try {
//String apikey = "pI2m1rcKm06OUfu9Ox0L0g";
//String senderid = "TESTIN";
//String channel = "2";
//String DCS = "0";
//String flashsms = "0";
//String mobile = "91"+mn;
//String message = "Amount of Rs. "+otp+" added to your account.Updated Balance is Rs."+b+" .";
//String route = "13";
//https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
//requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
//"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
//"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
//"&channel=" + URLEncoder.encode(channel, "UTF-8") +
//"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
//"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
//"&number=" + URLEncoder.encode(mobile, "UTF-8") +
//"&text=" + URLEncoder.encode(message, "UTF-8") +
//"&route=" + URLEncoder.encode(route, "UTF-8");
//URL url = new URL(requestUrl);
//HttpURLConnection uc = (HttpURLConnection)url.openConnection();
//System.out.println(uc.getResponseMessage());
//uc.disconnect();
//} catch(Exception ex) {
//System.out.println(ex.getMessage());
//}
//}
// public static void sendRefund(String b) {
//try {
//String apikey = "pI2m1rcKm06OUfu9Ox0L0g";
//String senderid = "TESTIN";
//String channel = "2";
//String DCS = "0";
//String flashsms = "0";
//String mobile = "91"+mn;
//String message = "Amount of Rs. "+otp+" refunded to your account.Updated Balance is Rs."+b+" .";
//String route = "13";
//https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
//requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
//"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
//"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
//"&channel=" + URLEncoder.encode(channel, "UTF-8") +
//"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
//"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
//"&number=" + URLEncoder.encode(mobile, "UTF-8") +
//"&text=" + URLEncoder.encode(message, "UTF-8") +
//"&route=" + URLEncoder.encode(route, "UTF-8");
//URL url = new URL(requestUrl);
//HttpURLConnection uc = (HttpURLConnection)url.openConnection();
//System.out.println(uc.getResponseMessage());
//uc.disconnect();
//} catch(Exception ex) {
//System.out.println(ex.getMessage());
//}
//}
// public static void AcceptOrder() {
//try {
//String apikey = "pI2m1rcKm06OUfu9Ox0L0g";
//String senderid = "TESTIN";
//String channel = "2";
//String DCS = "0";
//String flashsms = "0";
//String mobile = "91"+mn;
//String message = "Thank you for using V.E.S. Canteen. Your ORDERID "+otp+" is accepted.";
//String route = "13";
//https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
//requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
//"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
//"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
//"&channel=" + URLEncoder.encode(channel, "UTF-8") +
//"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
//"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
//"&number=" + URLEncoder.encode(mobile, "UTF-8") +
//"&text=" + URLEncoder.encode(message, "UTF-8") +
//"&route=" + URLEncoder.encode(route, "UTF-8");
//URL url = new URL(requestUrl);
//HttpURLConnection uc = (HttpURLConnection)url.openConnection();
//System.out.println(uc.getResponseMessage());
//uc.disconnect();
//} catch(Exception ex) {
//System.out.println(ex.getMessage());
//}
//}
// public static void DeclineOrder() {
//try {
//String apikey = "pI2m1rcKm06OUfu9Ox0L0g";
//String senderid = "TESTIN";
//String channel = "2";
//String DCS = "0";
//String flashsms = "0";
//String mobile = "91"+mn;
//String message = "Thank you for using V.E.S. Canteen. Sorry!Your ORDERID "+otp+" is declined due to some issues.Refund will be processed soon.";
//String route = "13";
//https://www.smsgatewayhub.com/api/mt/SendSMS?APIKey=YOURAPIKEY&senderid=YOURSENDERID&channel=2&DCS=0&flashsms=0&number=91XXXXX&text=hello%20this%20is%20testing%20message&route=
//requestUrl = "https://www.smsgatewayhub.com/api/mt/SendSMS?" +
//"APIKey=" + URLEncoder.encode(apikey, "UTF-8") +
//"&senderid=" + URLEncoder.encode(senderid, "UTF-8") +
//"&channel=" + URLEncoder.encode(channel, "UTF-8") +
//"&DCS=" + URLEncoder.encode(DCS, "UTF-8") +
//"&flashsms=" + URLEncoder.encode(flashsms, "UTF-8") +
//"&number=" + URLEncoder.encode(mobile, "UTF-8") +
//"&text=" + URLEncoder.encode(message, "UTF-8") +
//"&route=" + URLEncoder.encode(route, "UTF-8");
//URL url = new URL(requestUrl);
//HttpURLConnection uc = (HttpURLConnection)url.openConnection();
//System.out.println(uc.getResponseMessage());
//uc.disconnect();
//} catch(Exception ex) {
//System.out.println(ex.getMessage());
//}
//}
//}
//
