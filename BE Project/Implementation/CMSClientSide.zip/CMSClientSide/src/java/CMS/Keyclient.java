/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CMS;


import java.math.*;
import java.util.*;
import java.security.*;

    public class Keyclient 
{
          public static BigInteger a,p,g,k,X,y2,y1;
            public void encrypt()
            {
                final long serialVersionUID;
                serialVersionUID = 1L;
                Random sc=new SecureRandom();
                KeyStore key=new KeyStore();
                p = key.getPublicKey();
                a = key.geta();
                g = key.getg();    
                k = new BigInteger(2048, sc);
                y2 = a.modPow(k, p).mod(p);
                y1 = g.modPow(k, p);
                 
            }	
           public BigInteger getkeyy2()
            {
           return y2;
            }
           public BigInteger getkeyy1()
            {
           return y1;
            }
}
