package CMS;

import java.math.*;

public class Decrypt 
{       
        public static BigInteger a,p,g,k,x;

    /**
     *
     * @param D
     * @param E
     * @return
     */
    public BigInteger decrypt(BigInteger D,BigInteger E)
        {
        KeyStore key=new KeyStore();
        x=key.getPrivateKey();
        p=key.getPublicKey();
        BigInteger crmodp = D.modPow(x, p);
        BigInteger d = crmodp.modInverse(p);
        BigInteger ad = d.multiply(E).mod(p);
        
        return ad;
        }
}
        