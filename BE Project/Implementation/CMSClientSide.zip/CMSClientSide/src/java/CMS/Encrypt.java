package CMS;

import java.math.*;
import java.util.*;
import java.security.*;

public class Encrypt 
{
          public static BigInteger a,p,g,k,X,E,D;
            public void encrypt(String s)
            {
                final long serialVersionUID;
                serialVersionUID = 1L;
                Random sc=new SecureRandom();
                KeyStore key=new KeyStore();
                p = key.getPublicKey();
                a = key.geta();
                g = key.getg();    
                X = new BigInteger(s);
                k = new BigInteger(2048, sc);
                E = X.multiply(a.modPow(k, p)).mod(p);
                D = g.modPow(k, p);
                 
            }	
            public BigInteger getE()
            {
           return E;
            }
            public BigInteger getD()
            {
           return D;
            }
}
    